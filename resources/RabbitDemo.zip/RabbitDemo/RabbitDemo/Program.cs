﻿using System;
using System.Text;
using RabbitMQ.Client;
using RabbitMQ.Client.Content;

namespace RabbitDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            var factory = new ConnectionFactory() { HostName = "datdb.cphbusiness.dk" };
            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                channel.QueueDeclare(queue: "hello",
                                     durable: false,
                                     exclusive: false,
                                     autoDelete: false,
                                     arguments: null);          
        
                Order o = new Order(1, "test ordre");      
                                       
                var body = Encoding.UTF8.GetBytes(o.ToString());

                // message 1 publish without header info (properties)
                channel.BasicPublish(exchange: "",
                                routingKey: "hello",
                                basicProperties: null,
                                body: body);                
              

                var props =  channel.CreateBasicProperties();
                props.Type = "RabbitDemo.Order";    
              
                // message 2 publish with header info (properties)
                channel.BasicPublish(exchange: "",
                                    routingKey: "hello",
                                    basicProperties: props,
                                    body: body);
                
                IBasicProperties props2 = channel.CreateBasicProperties();
                props2.ContentType = "text/plain ... not!";
                props2.DeliveryMode = 2;

                byte[] serialized = ObjectSerialize.serialize(o);

                // message 3 publish serialized
                channel.BasicPublish(exchange: "",
                routingKey:"hello",
                basicProperties: props2,
                body: serialized);


                IMapMessageBuilder b = new MapMessageBuilder(channel);
                b.Headers["header1"] = "some@random.string";
                b.Headers["header2"] = "another@random.string";

                // message 4 publish with header info (properties)
                channel.BasicPublish(exchange:"", 
                    routingKey:"hello", 
                    basicProperties:
                        (IBasicProperties) b.GetContentHeader(), 
                    body: body);
                    

                Console.WriteLine(" [x] Sent {0} as {1}", o, body);
            }

            Console.WriteLine(" Press [enter] to exit.");
            Console.ReadLine();
        }
    }
}
