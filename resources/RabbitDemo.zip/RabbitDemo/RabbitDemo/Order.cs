﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RabbitDemo
{
    [Serializable]
    class Order
    {
        private int ono;
        private String description;

        public Order(int ono, String description)
        {
            this.ono = ono;
            this.description = description;
        }

        public override string ToString()
        {
            return ono.ToString() + ": " + description;
        }
    }
}
