﻿using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;

namespace RabbitDemo
{
    class ObjectSerialize
    {
        public static byte[] serialize(object obj)
        {
            if (obj == null)
            {

                return null;
            }

            using (var memoryStream = new MemoryStream())
            {

                var binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(memoryStream, obj);

                var compressed = Compress(memoryStream.ToArray());
                return (byte[]) compressed;
            }
        }

        private static object Compress(byte[] input)
        {
            byte[] compressesData;

            using (var outputStream = new MemoryStream())
            {
                using (var zip = new GZipStream(outputStream, CompressionMode.Compress))
                {

                    zip.Write(input, 0, input.Length);

                }


                compressesData = outputStream.ToArray();
            }

            return compressesData;

        }
    }
}
