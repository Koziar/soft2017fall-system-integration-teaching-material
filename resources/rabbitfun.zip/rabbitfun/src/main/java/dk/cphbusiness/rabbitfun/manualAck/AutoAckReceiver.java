package dk.cphbusiness.rabbitfun.manualAck;

import java.io.IOException;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.ConsumerCancelledException;
import com.rabbitmq.client.QueueingConsumer;
import com.rabbitmq.client.ShutdownSignalException;

public class AutoAckReceiver {
public static void main(String[] args) throws IOException, ShutdownSignalException, ConsumerCancelledException, InterruptedException {
	ConnectionFactory connfac = new ConnectionFactory();
	connfac.setHost("datdb.cphbusiness.dk");
	connfac.setVirtualHost("student");
	connfac.setUsername("student");
	connfac.setPassword("cph");
    Connection connection = connfac.newConnection();
    Channel channel = connection.createChannel();
    
    String exchangeName= "manualAckTrue";
    channel.exchangeDeclare(exchangeName, "direct");
    String queueName= "autoack";
    channel.queueDeclare(queueName,false,false,false,null);
    channel.queueBind(queueName, exchangeName, "key");
    
    QueueingConsumer consumer = new QueueingConsumer(channel);
    channel.basicConsume(queueName, false, consumer);
    
    
    while (true) {
      QueueingConsumer.Delivery delivery = consumer.nextDelivery();
      String message = new String(delivery.getBody());
      String routingKey = delivery.getEnvelope().getRoutingKey();

      System.out.println(" [x] Received '" + routingKey + "':'" + message + "'");
      channel.basicAck(delivery.getEnvelope().getDeliveryTag(), false);
      
//      To reject the message use one of the following methods
//      channel.basicNack(delivery.getEnvelope().getDeliveryTag(), false, true);
      //or
//      channel.basicReject(delivery.getEnvelope().getDeliveryTag(), true);
      
    }
}
}
