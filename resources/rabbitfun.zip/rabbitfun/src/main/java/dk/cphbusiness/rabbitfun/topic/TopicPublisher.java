package dk.cphbusiness.rabbitfun.topic;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class TopicPublisher {

	private static final String EXCHANGE_NAME = "topic_logs";

	public static void main(String[] args) throws IOException {

		ConnectionFactory connfac = new ConnectionFactory();
		connfac.setHost("datdb.cphbusiness.dk");
		connfac.setUsername("student");
		connfac.setPassword("cph");
        Connection connection = connfac.newConnection();
        Channel chan = connection.createChannel();

		chan.exchangeDeclare(EXCHANGE_NAME, "topic");
		// In this example, the routing key and the message are the same. If you
		// want to change, just change the way either routingKey or message gets
		// located:
		String in;
		ArrayList<String> topic = new ArrayList<String>();
		topic.add("");
		topic.add(".hej");
		topic.add("here.comes.more.than.1.routing.key");
		topic.add("*");
		topic.add("#");
		topic.add(".key.");
		topic.add("");
		Iterator<String> it= topic.iterator();
		
		while (it.hasNext()) {
			in=it.next();

			String routingKey =in; 
			String message =  in;

			// Exchange
			chan.basicPublish(EXCHANGE_NAME, routingKey, null,
					message.getBytes());

			System.out.println(" [x] Sent '" + message + "'");

		}

		chan.close();
		connection.close();
	}

	private static String getMessage(String strings) {
		
			return "Hello World!";
		
	}

	private static String getRouting(String strings) {
			return "anonymous.info";
	}
	/**
	 * This method is not getting used anymore. Delete if you want to.
	 * @param strings
	 * @param delimiter
	 * @return
	 */
	private static String joinStrings(String[] strings, String delimiter) {
		int length = strings.length;
		if (length == 0)
			return "";
		StringBuilder words = new StringBuilder(strings[0]);
		for (int i = 1; i < length; i++) {
			words.append(delimiter).append(strings[i]);
		}
		return words.toString();
	}
}
