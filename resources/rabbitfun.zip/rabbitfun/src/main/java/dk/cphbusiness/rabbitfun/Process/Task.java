package dk.cphbusiness.rabbitfun.Process;

import java.io.IOException;

import com.rabbitmq.client.AMQP.BasicProperties;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.ConsumerCancelledException;
import com.rabbitmq.client.QueueingConsumer;
import com.rabbitmq.client.ShutdownSignalException;

public class Task implements Runnable {
	String queueName;
	public Task( String queuename) {
		queueName=queuename;
	}
public static void main(String[] args) throws IOException, ShutdownSignalException, ConsumerCancelledException, InterruptedException {
	
	
	Thread t1 = new Thread(new Task("task1")); 
	Thread t2 = new Thread(new Task("task2"));
	Thread t3 = new Thread(new Task("task3"));
	t1.start();
	t2.start();
	t3.start();
}

public void run() {
	ConnectionFactory connfac = new ConnectionFactory();
	connfac.setHost("datdb.cphbusiness.dk");
	connfac.setUsername("student");
	connfac.setPassword("cph");
	Connection connection;
	try {
		connection = connfac.newConnection();
	Channel channel = connection.createChannel();
	String queue= queueName;
	channel.queueDeclare(queue, false, false, false, null);
	//Setting up the consumer;
	 QueueingConsumer consumer = new QueueingConsumer(channel);
	  channel.basicConsume(queue, true, consumer);

	while (true) {
		QueueingConsumer.Delivery delivery = consumer.nextDelivery();
		BasicProperties bp = delivery.getProperties();
		//Unpack the reply queue
		String replyQueue = bp.getReplyTo();
		
		String msg= new String(delivery.getBody());
		System.out.print("Queue named: "+queueName);
		System.out.print("\tMessage: "+msg);
		System.out.print("\tCorrelation ID: "+bp.getCorrelationId());
		System.out.print("\t. Replying to: "+replyQueue+"\n");
		msg+=" "+queue;
		
		channel.basicPublish("", replyQueue, bp,msg.getBytes());
	}
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (ShutdownSignalException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (ConsumerCancelledException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
