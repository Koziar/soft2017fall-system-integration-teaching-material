package dk.cphbusiness.rabbitfun.topic;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import com.rabbitmq.client.AMQP.Queue.BindOk;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.ConsumerCancelledException;
import com.rabbitmq.client.QueueingConsumer;
import com.rabbitmq.client.ShutdownSignalException;

public class TopicSubscriber {

	private static final String EXCHANGE_NAME = "topic_logs";

	public static void main(String[] args) throws IOException,
			ShutdownSignalException, ConsumerCancelledException,
			InterruptedException {
		ConnectionFactory connfac = new ConnectionFactory();
		connfac.setHost("datdb.cphbusiness.dk");
		connfac.setUsername("student");
		connfac.setPassword("cph");
        Connection connection = connfac.newConnection();
        Channel channel = connection.createChannel();

		String in;

		channel.exchangeDeclare(EXCHANGE_NAME, "topic");
		String queueName = channel.queueDeclare().getQueue();


		System.out.println(" [*] Waiting for messages. To exit press CTRL+C");
		QueueingConsumer consumer = new QueueingConsumer(channel);
		boolean autoAck = true;
		
		System.out.println("Please state the input for binding, followed by quit command:");
		ArrayList<String> topic = new ArrayList<String>();
//		topic.add("error.http");
//		topic.add("#");
//		topic.add("#.key.#");
//		topic.add("*");
		topic.add(".*");
//		topic.add(".");
		
		Iterator<String> it= topic.iterator();
		
		while (it.hasNext()) {

			in = it.next();
						
			channel.basicConsume(queueName, autoAck, consumer);
			BindOk bOk =channel.queueBind(queueName, EXCHANGE_NAME, in);
			System.out.println("Binding on: " + in +"with bind OK="+ bOk.protocolMethodName());
			System.out.println("If you are done with binding and wants to listen, write 'quit'");
		}

		while (true) {
			QueueingConsumer.Delivery delivery = consumer.nextDelivery();
			String message = new String(delivery.getBody());
			String routingKey = delivery.getEnvelope().getRoutingKey();
			String exchange =delivery.getEnvelope().getExchange();
			System.out.println(" [x] Received '" + routingKey + "':'" + message
					+ "'"+ " from exchange: '"+exchange+"'");
		}
	}
}
