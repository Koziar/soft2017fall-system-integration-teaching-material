package dk.cphbusiness.rabbitfun.Process;

import java.io.IOException;

import com.rabbitmq.client.AMQP.BasicProperties;
import com.rabbitmq.client.AMQP.BasicProperties.Builder;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.ConsumerCancelledException;
import com.rabbitmq.client.QueueingConsumer;
import com.rabbitmq.client.ShutdownSignalException;

public class ProcessManager {
	static String queueReply1;
	static String queueReply2;
	static String queueReply3;
	static String task1Queue;
	static String task2Queue;
	static String task3Queue;
	public static void main(String[] args) throws IOException, ShutdownSignalException, ConsumerCancelledException, InterruptedException {
		ConnectionFactory connfac = new ConnectionFactory();
		connfac.setHost("datdb.cphbusiness.dk");
		connfac.setUsername("student");
		connfac.setPassword("cph");
		Connection connection = connfac.newConnection();
		Channel channel = connection.createChannel();
		channel.basicQos(1);
		//Setting up the queues;
		task1Queue= "task1";
		task2Queue= "task2";
		task3Queue= "task3";
		channel.queueDeclare(task1Queue, false, false, false, null);
		channel.queueDeclare(task2Queue, false, false, false, null);
		channel.queueDeclare(task3Queue, false, false, false, null);
		
		//Setting up the replyqueues;
		queueReply1 = channel.queueDeclare().getQueue();
		queueReply2 = channel.queueDeclare().getQueue();
		queueReply3 = channel.queueDeclare().getQueue();
		//send the messages off to task one
		System.out.println("sending messages to task #1");
		for (int i = 0; i < 10; i++) {
			Builder builder = new BasicProperties.Builder();
			builder.correlationId("" + i);
			builder.replyTo(queueReply1);
			BasicProperties props =builder.build();
//			System.out.println(props.toString());
			channel.basicPublish("", task1Queue, props,("msg nr: "+i).getBytes());

		}
		//Setting up the consumer;
		 QueueingConsumer consumer = new QueueingConsumer(channel);
		  channel.basicConsume(queueReply1, true, consumer);
		  channel.basicConsume(queueReply2, true, consumer);
		  channel.basicConsume(queueReply3, true, consumer);

		while (true) {
			QueueingConsumer.Delivery delivery = consumer.nextDelivery();
			BasicProperties props = delivery.getProperties();
			
			if(!props.getReplyTo().equalsIgnoreCase(queueReply3)){
			String replyToNow=determineReplyToQueue(props.getReplyTo());
			String nextQueue = determineNextQueue(delivery.getEnvelope().getRoutingKey());
		    BasicProperties replyProps = new BasicProperties
		    									 .Builder()
		                                         .correlationId(props.getCorrelationId())
		                                         .replyTo(replyToNow)
		                                         .build();
			channel.basicPublish("", nextQueue, replyProps,delivery.getBody());
			}else{
			System.out.println("Work done for message with id: "+ delivery.getProperties().getCorrelationId() +" and msg: "+new String(delivery.getBody()));
//			System.out.println("details: "+ delivery.getProperties().toString());
			}
		}
	}

	
	
	private static String determineNextQueue(String routingKey) {
		if(routingKey.equalsIgnoreCase(queueReply1)){
			return task2Queue;
		}else if(routingKey.equalsIgnoreCase(queueReply2)){
			return task3Queue;
		}
		return null;
	}

	private static String determineReplyToQueue(String replyTo) {
		if(replyTo.equalsIgnoreCase(queueReply1)){
			return queueReply2;
		}else if(replyTo.equalsIgnoreCase(queueReply2)){
			return queueReply3;
		}
		return null;
	}
}
